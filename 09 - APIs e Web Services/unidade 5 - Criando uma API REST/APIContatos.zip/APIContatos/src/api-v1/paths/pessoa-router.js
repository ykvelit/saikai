import express from 'express';
import pessoaModel from '../models/pessoa-model';

const pessoaRouter = express.Router();

//pessoaRouter.use('/', (req, res, next) => res.send('ENDPOINT PESSOA'));
pessoaRouter.get('/', listaPessoa);
pessoaRouter.post('/', inserePessoa);




function listaPessoa (req, res, next) {
    pessoaModel.lista ({}, (err, lista) => {
        if (err) {            
            res.status (400).send (err.message);
        } else
            res.json (lista);
    });
}

function inserePessoa (req, res, next) {
    pessoaModel.insere (req.body, (err, obj) => {
        if (err) {
            res.status (400).send (err.message);
        }
        else
            res.json (obj)
    });
}


export default pessoaRouter;