import db from '../utils/db';

function lista (params, callback) {
    // const objFake = [
    //     {
    //       "id": 5,
    //       "nome": "Francis Ford Copolla",
    //       "email": "copolla@hollywood.com",
    //       "telefone": "001-124-2111",
    //       "organizacao": null,
    //       "tags": [
    //         "cinema",
    //         "trabalho"
    //       ]
    //     }
    //   ];

    db.pessoasDB.find ({}, callback);
}

function insere (obj, callback) {
    db.pessoasDB.insert (obj, callback);
}

function altera (id, obj, callback) {

    callback (objAlterado);
}

function exclui (id, callback) {

    callback (resultado);
}

export default {
    lista, 
    insere, 
    altera, 
    exclui
}