# Content

[![Build Status](https://travis-ci.org/micro-frontends-demo/content.svg?branch=master)](https://travis-ci.org/micro-frontends-demo/content)

Static content for a micro frontends demo.

Contains global styles that everyone should use, and common content like images.
This is a dependency for some of the other apps.

# Getting started

1. Clone the repo
2. `yarn install`
3. `yarn build`
3. `yarn start`
