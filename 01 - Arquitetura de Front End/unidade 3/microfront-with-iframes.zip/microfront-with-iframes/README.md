# Instruções

* Entre na pasta `satellite` via linha de comando e rode o comando `npm install && npm start`.

* Em seguida, faça o mesmo dentro das pastas `fragment-1` e `fragment-2`.

* Entre em `http://localhost:8000` e veja a aplicação rodando.
