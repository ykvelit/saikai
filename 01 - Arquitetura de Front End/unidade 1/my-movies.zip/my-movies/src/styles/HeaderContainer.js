import styled from 'styled-components';

export const HeaderContainer = styled.header`
    text-align: center;
    padding: 50px 0;
`