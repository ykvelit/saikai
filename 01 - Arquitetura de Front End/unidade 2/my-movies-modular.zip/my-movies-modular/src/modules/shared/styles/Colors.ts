export const Colors = {
    primary: '#fc7a30',
    secondary: '#D35B18',
    darkRed: 'darkred',
    black: 'black',
    white: 'white',
};
