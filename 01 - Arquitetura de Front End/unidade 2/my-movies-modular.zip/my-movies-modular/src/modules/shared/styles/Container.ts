import styled from 'styled-components';

export const Container = styled.section`
    width: 80%;
    margin: 0 auto;
`;
