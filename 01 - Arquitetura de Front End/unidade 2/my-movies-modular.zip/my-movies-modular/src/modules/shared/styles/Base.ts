import { createGlobalStyle } from 'styled-components';

export const BaseStyle = createGlobalStyle`
  body {
    font-family: 'Oxygen', sans-serif;
  }
`;
