import styled from 'styled-components';

export const InputField = styled.div`
    padding: 10px;
`;
