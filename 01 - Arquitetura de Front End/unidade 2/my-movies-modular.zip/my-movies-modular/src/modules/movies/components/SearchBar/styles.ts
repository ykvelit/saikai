import styled from 'styled-components';

export const SearchBarForm = styled.form`
    width: 500px;
    margin: 0 auto;
    display: flex;
    align-items: center;
`;
