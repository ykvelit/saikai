import bar from './bar';
import './styles.scss';

bar();
