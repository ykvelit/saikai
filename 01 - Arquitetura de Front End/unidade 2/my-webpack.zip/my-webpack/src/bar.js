export default function bar() { console.log('Hello world') }
